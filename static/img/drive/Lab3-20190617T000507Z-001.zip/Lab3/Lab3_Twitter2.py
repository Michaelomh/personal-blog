'''

Lab 3 - Twitter Rest API (Search API)
Ref: https://dev.twitter.com/rest/public/search

'''

import tweepy
from tweepy import OAuthHandler

# Consumer/Access key/secret/token obtained from Twitter
# You should have created a Twitter app and gotten these keys.
# Do NOT share your key/secret/token with other students.
consumer_key = 'xeXGwwXAkZsCLjXYlgTeQXqf9'
consumer_secret = 'b4BoFTR74ShjCAfyDWug5zmZ6UFNlntRmZOb6ZwbikErQe4Ut2'
access_token = '177596182-wt41IEWCf7yAYmscSYdMU24YSzdDsg7ctEO9RUw4'
access_secret = 'KQnLCPDQM5QjrbcaJR7gdkpdm09i8KIsGgIdDe0hS7rf5'

# The following two lines create an authorization object with your above authentication info.
auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

# This line finally calls Twitter's Rest API.
api = tweepy.API(auth)

# This FOR loop will retrieve the latest 10 tweets - based on search term(s)
for tweet in tweepy.Cursor(api.search, q='iphone galaxy').items(10):
    # print out usernames of the last 10 people to use #trump in their tweets
    print ('Tweet by: @' + tweet.user.screen_name)
    print('       ' + tweet.text)


'''
watching now	        containing both “watching” and “now”. This is the default operator.
“happy hour”	        containing the exact phrase “happy hour”.
love OR hate	        containing either “love” or “hate” (or both).
beer -root	            containing “beer” but not “root”.
#haiku	                containing the hashtag “haiku”.
from:interior	        sent from Twitter account “interior”.
to:NASA	                a Tweet authored in reply to Twitter account “NASA”.
@NASA	                mentioning Twitter account “NASA”.
politics filter:safe	containing “politics” with Tweets marked as potentially sensitive removed.
'''