'''
Lab 3 - Part 2

Web Scraping using Python

In "Lab 3 - Part 1", we used RapidMiner's Web Mining extension to crawl a blogger's blog entries
as HTML files.

In this Python script, we use BeautifulSoup package in Python - to perform web scraping, whereby
we attempt to extract out only certain text content.

In this lab, we are particularly interested in extracting a given blog entry's:

1) Title
2) Date (of entry)
3) Blog content (essay)

'''

######## Step 1 ########
'''
You need to go and install the following packages. And then, import them so we can use it.
1) requests
2) bs4
'''
import requests
from bs4 import BeautifulSoup

######## Step 2 ########
'''
Later on, you will need to modify this script to read MULTIPLE HTML files from a directory.
For now, we're going to connect to the blogger's blog entry via HTTP.
To do that, we simply specify the blog entry's URL.
'''
#blog_entry_path = r"C:\Users\kjshim\Desktop\IS434_RapidMiner\Lab2\Crawl003_2016_Subset\11.html"
#source_path = "C:\\Users\\kjshim\\Desktop\\IS434_RapidMiner\\Lab2\\Crawl003_2016_Subset\\11.html"
source_path = "sample_html_pages/7.html"
page = open(source_path, encoding="utf8")
page_content = page.read()

######## Step 3 ########
'''
The way BeautifulSoup works is... you need to grab the blog entry's HTML content
--> page.content
And then, you need to tell BeautifulSoup that you want it to "parse" page's HTML content
--> 'html.parser'
'''
soup = BeautifulSoup(page_content, 'html.parser')
'''
prettify() function will do indentation so that the extracted HTML content has
HTML tags nicely indented for easy viewing.
Try uncommenting the below line and print.
'''
#print (soup.prettify())


######## Step 4 ########
'''
This line calls find_all() function to look for 'div' tag with class='post-header'.
find_all() returns us a LIST.
What we want is the FIRST item in this LIST.
As you know... in Python (and in many other programming languages),
the FIRST guy in a list/array has the INDEX value of 0 (zero).
So, we're going to add [0] to the end of the line - to extract the FIRST div with class='post-header'.

Why are we interested in extracting this div?
Inside this div... are: 1) title, 2) date of the blog entry.

this div... looks like this

<div class="post-header">
    <h1>
        First Home- Singapore's Largest Development EC, Sol Acres
    </h1>
    <span class="date">Friday, August 25, 2017</span>
</div>
'''
title_date_div = soup.find_all('div', class_='post-header')[0]
#print(title_date_div)


######## Step 5 ########
'''
title_date_div contains what we want... 1) title and 2) date.

<div class="post-header">
    <h1>
        First Home- Singapore's Largest Development EC, Sol Acres
    </h1>
    <span class="date">Friday, August 25, 2017</span>
</div>

We need to extract out the blog entry's "title", inside <h1>.
How do we get ... just the TEXT portion ... inside <h1> ... </h1>?

First, we need to find h1 tag inside the div.
--> find('h1')

After this, to extract just the TEXT portion... we call get_text() function.
Try this and print. See what you get.
'''
title = title_date_div.find('h1').get_text()
# In case... the title content has end-of-line (\n), we don't want it - we want it removed.
# We use replace() function to replace (if any) '\n' (end-of-line character) with empty string ('').
title = title.replace('\n', '')
print(title)


######## Step 6 ########
'''
Same thing here.. we need to get "date" of this blog entry.

<div class="post-header">
    <h1>
        First Home- Singapore's Largest Development EC, Sol Acres
    </h1>
    <span class="date">Friday, August 25, 2017</span>
</div>

The "date" we want... is inside <span>... </span>.
--> find('span')
This finds us <span>...</span>.
Note that you can also... look for a tag with class="date" by doing:
--> find(class_='date')
Either way is fine.

Once you get the span... call get_text() function to extract the TEXT portion,
which is essentially what we want --> blog entry's DATE. :)

Try the below code and see what you get.
'''
date = title_date_div.find('span').get_text()
#date = title_date_div.find(class_='date').get_text()
# In case... the date content has end-of-line (\n), we don't want it - we want it removed.
# We use replace() function to replace (if any) '\n' (end-of-line character) with empty string ('').
date = date.replace('\n', '')
print(date)


######## Step 7 ########
'''
Here, we need to capture blog's main content (essay portion).

If you look at the HTML content... you'll see that the blogger's article consists of
a series of:

 <div class="separator" style="clear: both; text-align: center;">
    some content...
 </div>

On her website, the content looks like a contiguous block of text but the HTML isn't.
So, we need BeautifulSoup to extract ALL ... <div class="separator"> tags.

When it does, it will insert all matched entries into a LIST.
'''
essay_div = soup.find_all('div', class_='separator')

'''
What we'll do now... is to LOOP THRU this LIST of <div class="separator"> tags...
and extract out the TEXT portion.
One by one...as we extract out the TEXT portion of the tag, we will append it to essay_content text variable.

In the end, essay_content will contain the ENTIRE blog entry's essay portion.
'''

# We initialize essay_content string... to an empty string.
essay_content = ""

# We LOOP THRU the list of div tags...
for segment in essay_div:
    # segment is a div object - we need to extract out the TEXT portion by calling get_text() function.
    segment_text = segment.get_text()
    # If the TEXT portion contains end-of-line character (\n), remove it.
    # We use replace() function to do this operation.
    segment_text = segment_text.replace('\n', '')

    # If the extracted TEXT portion after stripping off \n ... is NOT empty, then it must be
    # containing some essay content... so append it to essay_content string.
    if segment_text is not "":
        #print(segment_text)
        essay_content = essay_content + segment_text + ' '

'''
We're done grabbing all the essay content.
Let's print and see what it looks like.
'''
print (essay_content)