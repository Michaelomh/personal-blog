'''

Lab 3 - Twitter Streaming API

Streaming API allows for (almost) continous connnection.
It allows programs (such as this one) to keep crawling new tweets without manually making a call again and again.

'''

from tweepy import Stream
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler

# This class defines MyListener class - an object of which essentially
# keeps the connection going and keep pulling new tweets from Twitter server.
class MyListener(StreamListener):
    def on_data(self, data):
        try:
            with open('Lab4_UKtext.txt', 'a') as f:
                print(data)
                f.write(data)
                return True
        except BaseException as e:
            print("Error on_data: %s" % str(e))
        return True

    def on_error(self, status):
        print(status)
        return True

# Consumer/Access key/secret/token obtained from Twitter
# You should have created a Twitter app and gotten these keys.
# Do NOT share your key/secret/token with other students.
consumer_key = 'xeXGwwXAkZsCLjXYlgTeQXqf9'
consumer_secret = 'b4BoFTR74ShjCAfyDWug5zmZ6UFNlntRmZOb6ZwbikErQe4Ut2'
access_token = '177596182-wt41IEWCf7yAYmscSYdMU24YSzdDsg7ctEO9RUw4'
access_secret = 'KQnLCPDQM5QjrbcaJR7gdkpdm09i8KIsGgIdDe0hS7rf5'

# The following two lines create an authorization object with your above authentication info.
auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

# This line finally calls Twitter's Streaming API.
twitter_stream = Stream(auth, MyListener())

# Here, we define our query terms - inside a list.
# For example, below, we crawl all tweets m entioning #donaldtrump or #hillary2016.
# For more details refer to https://dev.twitter.com/docs/streaming-apis
query_terms = ['London', 'londonexplosion', 'explosion', 'explosionlondon', 'UK']
twitter_stream.filter(track=query_terms)