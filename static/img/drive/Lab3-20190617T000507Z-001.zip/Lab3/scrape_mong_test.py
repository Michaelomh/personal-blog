'''
Lab 3 - Part 2

Web Scraping using Python

In "Lab 3 - Part 1", we used RapidMiner's Web Mining extension to crawl a blogger's blog entries
as HTML files.

In this Python script, we use BeautifulSoup package in Python - to perform web scraping, whereby
we attempt to extract out only certain text content.

In this lab, we are particularly interested in extracting a given blog entry's:

1) Title
2) Date (of entry)
3) Blog content (essay)
'''

'''
"scrape_mong.py" is a Python script we wrote - it contains a function called "web_scrape()".
Go open "scrape_mong.py" and have a look at this function.

In order to import a local package, all you need to do is...
import <your_python_script_name_excluding_py_at_the_end>
'''
import scrape_mong

####### Test 1 - Web Scrape from an online webpage #######
source_path = "http://www.mongabong.com/2017/08/largest-executive-condo-sol-acres.html"
# Call web_scrape function
# Don't forget the TWO parameters
result = scrape_mong.web_scrape('web', source_path)
# web_scrape() returns a LIST containing:
# 1) blog entry's title
# 2) blog entry's date
# 3) blog entry's content (essay)
for line in result:
    print (line)


####### Test 2 - Web Scrape from a local file #######
# You can specify the ABSOLUTE PATH this way.
# If you're using Windows OS, your file path will use backslash.
# Don't worry - you don't have to manually reverse them into forward slash.
# You simply need to specify "r" at the start of the file path like below.
#source_path = r"C:\Users\kjshim\Desktop\IS434_RapidMiner\Lab2\Crawl003_2016_Subset\11.html"

# You can point to a local file using RELATIVE path this way.
# We provided 5 local HTML files for you inside this project.
source_path = "sample_html_pages/7.html"
# Call web_scrape function
# Don't forget the TWO parameters
result = scrape_mong.web_scrape('local', source_path)
# web_scrape() returns a LIST containing:
# 1) blog entry's title
# 2) blog entry's date
# 3) blog entry's content (essay)
for line in result:
    print(line)
