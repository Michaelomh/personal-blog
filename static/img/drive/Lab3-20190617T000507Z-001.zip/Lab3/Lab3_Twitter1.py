'''

Lab 3 - Twitter Rest API
Ref: https://dev.twitter.com/rest/public/search

'''

import tweepy
from tweepy import OAuthHandler

# Consumer/Access key/secret/token obtained from Twitter
# You should have created a Twitter app and gotten these keys.
# Do NOT share your key/secret/token with other students.
consumer_key = 'xeXGwwXAkZsCLjXYlgTeQXqf9'
consumer_secret = 'b4BoFTR74ShjCAfyDWug5zmZ6UFNlntRmZOb6ZwbikErQe4Ut2'
access_token = '177596182-wt41IEWCf7yAYmscSYdMU24YSzdDsg7ctEO9RUw4'
access_secret = 'KQnLCPDQM5QjrbcaJR7gdkpdm09i8KIsGgIdDe0hS7rf5'

# The following two lines create an authorization object with your above authentication info.
auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

# This line finally calls Twitter's Rest API.
api = tweepy.API(auth)

# This FOR loop will retrieve the latest 10 tweets (on your timeline).
for status in tweepy.Cursor(api.home_timeline).items(10):
    # Process a single status
    status_msg = status.text
    # Method 2 - manual encoding (uncomment the below line, if want to use it)
    #status_msg = (status.text).encode('ascii', 'ignore').decode('ascii')
    print (status_msg)
