'''
Lab 4

In this script, we will draw some statistics and visualize it.
'''

import json
import pandas as pd
import matplotlib.pyplot as plt

# Our input file contains one or more lines of Tweets
# Remember? A "tweet" returned to us by the Twitter API is a JSON object.

############### Section 1 ###############

# Specify input file
tweets_data_path = 'Twitter_Output_DonaldTrumpHillary2016.txt'

# Open the file. 'r' means READ.
tweets_file = open(tweets_data_path, 'r')

# This LIST will contain tweet objects. Initialize it to empty.
tweets_list = []

# Read one line at a time
for line in tweets_file:
    # strip() function removes end-of-line characters at the end
    # After removing end-of-line characters, see if the line still
    # contains any data. If it does, len() will be > 0.
    # If that's the case, let's save this Tweet Object into our LIST.
    if len(line.strip()) > 0:
        tweet = json.loads(line) # each line is a JSON object
        if 'text' in tweet:
            tweets_list.append(tweet)

# So... how many tweet objects have 'text' content inside?
print (len(tweets_list))


############### Section 2 ###############
# We will use "pandas" package to draw bar charts.
# We need to use a specific "Data Frame" used by pandas.
tweets = pd.DataFrame()

# It will extract "text" element in tweets_list.
# Go to JSON Viewer and locate "text" element.
tweets['text'] = list(map(lambda tweet: tweet['text'], tweets_list))

# This line extracts "lang" element in tweets data.
tweets['lang'] = list(map(lambda tweet: tweet['lang'], tweets_list))

# This line extracts "country" element in tweets data.
# "country" is a child of "place" in the JSON hierarchy.
tweets['country'] = list(map(lambda tweet: tweet['place']['country']
                        if tweet['place'] != None
                        else
                            None,
                    tweets_list))

# So... how many tweets have 'text', 'lang' and 'country'.
print ('# of tweets with text   : ', len(tweets['text']))
print ('# of tweets with lang   : ', len(tweets['lang']))
print ('# of tweets with countr : ', len(tweets['country']))

# Have a look at what lambda/map returned to us. Let’s have a look at the first 10 items.
print ( (tweets['text'])[0:10] )


############### Section 3 ###############
# Chart 1: how many tweets are written in English ('en') versus others...
# value_counts() function is useful here.
tweets_by_lang = tweets['lang'].value_counts()

# Let's have a look at what value_counts() function returned.
# It returns a list of 2-column items.
# Column 1: "langauge"
# Column 2: frequency
print (tweets_by_lang)

# Let’s make a Bar Chart – showing top 10 languages
# Let's create a Figure (image) and Axis (so we can customize how the figure looks).
fig, axis = plt.subplots()
axis.tick_params(axis='x', labelsize=8)
axis.tick_params(axis='y', labelsize=8)
axis.set_xlabel('Languages', fontsize=8)
axis.set_ylabel('Number of Tweets', fontsize=8)
axis.set_title('Top 10 Languages', fontsize=8, fontweight='bold')

# Now that X/Y axes are all customized and figure Title is set
# Let's grab the Top 10 langauges from our Tweets
# Create a Bar Chart with the bars in RED color.
tweets_by_lang[:10].plot(ax=axis, kind='bar', color='red')

# Let's now display the Bar Chart.
plt.show()

# We can also save the Bar Chart as a PNG image file.
plt.savefig('Twitter_BarChart_Langauges.png')


############### Section 4 ###############
# Chart 2: how many tweets originate from the USA... versus other countries...
tweets_by_country = tweets['country'].value_counts()
fig, axis = plt.subplots()
axis.tick_params(axis='x', labelsize=6)
axis.tick_params(axis='y', labelsize=6)
axis.set_xlabel('Countries', fontsize=8)
axis.set_ylabel('Number of Tweets' , fontsize=8)
axis.set_title('Top 5 Countries', fontsize=8, fontweight='bold')
tweets_by_country[:5].plot(ax=axis, kind='bar', color='blue')

# Let's now display the Bar Chart.
plt.show()

# We can also save the Bar Chart as a PNG image file.
plt.savefig('Twitter_BarChart_Country.png')
