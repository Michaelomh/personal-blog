'''
Lab 4

In this script, we will explore NLTK package.
'''

import nltk

############### Section 1 ###############
# NTLK package comes with many books, on which we can perform text analysis.

# Which books are available?
print (nltk.corpus.gutenberg.fileids())

# Let's download 'Emma' by author Jane Austen.
# It returns a LIST of words.
emma_words = nltk.corpus.gutenberg.words('austen-emma.txt')
print (emma_words[:5])

# How many words are in this book?
print (len(emma_words))

# We can also download this book - broken down by 'setences'.
emma_sentences = nltk.corpus.gutenberg.sents('austen-emma.txt')
print (emma_sentences[:5])

# How many sentences are in this book?
print (len(emma_sentences))

# What is the longest sentence's length?
longest_sentence = max(len(s) for s in emma_sentences)
print (longest_sentence)
# Let's have a look at this sentence.
for sentence in emma_sentences:
    if len(sentence) == longest_sentence:
        print (sentence)

