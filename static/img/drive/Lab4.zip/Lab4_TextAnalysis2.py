'''
Lab 4

In this script, we will explore NLTK package.
'''

from nltk.tokenize import sent_tokenize, word_tokenize

############### Section 1 ###############

# Specify input file
news_article_path = 'StraitsTimes1.txt'

# Open the file, read in all the news content and make a single sentence.
news_article_file = open(news_article_path, 'r')
news_content = ''
# Read one line at a time
for line in news_article_file:
    if len(line.strip()) > 0:
        news_content = news_content + line + ' '

# See what it looks like.
print (news_content)

# Let's lower-case all words.
news_content = news_content.lower()

# See what it looks like.
print (news_content)


############### Section 2 ###############
# sent_tokenize() function takes a text blob and breaks it into 'sentences'.
news_sentences = sent_tokenize(news_content)
print (news_sentences)
# How many sentences are in this news article?
print (len(news_sentences))


############### Section 3 ###############
# word_tokenize() function takes a text blob and breaks it into 'words'.
news_words = word_tokenize(news_content)
print (news_words)
# How many words are in this news article?
print (len(news_words))

