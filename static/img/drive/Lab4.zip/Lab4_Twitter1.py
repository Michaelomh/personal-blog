'''
Lab 4

In this script, we will draw basic information from our large Twitter dataset.
'''

import json
import pandas as pd
import matplotlib.pyplot as plt

# Our input file contains one or more lines of Tweets
# Remember? A "tweet" returned to us by the Twitter API is a JSON object.

############### Section 1 ###############

# Specify input file
tweets_data_path = 'Twitter_Output_DonaldTrumpHillary2016.txt'

# Open the file. 'r' means READ.
tweets_file = open(tweets_data_path, 'r')

# This LIST will contain tweet objects. Initialize it to empty.
tweets_text_list = []

# Read one line at a time
for line in tweets_file:
    # strip() function removes end-of-line characters at the end
    # After removing end-of-line characters, see if the line still
    # contains any data. If it does, len() will be > 0.
    # If that's the case, let's save it into our LIST.
    if len(line.strip()) > 0:
        tweet = json.loads(line) # each line is a JSON object
        if 'text' in tweet:
            tweets_text_list.append(tweet)

# So... how many tweet objects have 'text' content inside?
print (len(tweets_text_list))