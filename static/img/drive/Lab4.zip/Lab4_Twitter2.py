'''
Lab 4

In this script, we will extract 1) text, 2) language, 3) country
from all tweets.
'''

import json
import pandas as pd
import matplotlib.pyplot as plt

# Our input file contains one or more lines of Tweets
# Remember? A "tweet" returned to us by the Twitter API is a JSON object.

############### Section 1 ###############

# Specify input file
tweets_data_path = 'Twitter_Output_DonaldTrumpHillary2016.txt'

# Open the file. 'r' means READ.
tweets_file = open(tweets_data_path, 'r')

# This LIST will contain tweet objects. Initialize it to empty.
tweets_list = []

# Read one line at a time
for line in tweets_file:
    # strip() function removes end-of-line characters at the end
    # After removing end-of-line characters, see if the line still
    # contains any data. If it does, len() will be > 0.
    # If that's the case, let's save this Tweet Object into our LIST.
    if len(line.strip()) > 0:
        tweet = json.loads(line) # each line is a JSON object
        if 'text' in tweet:
            tweets_list.append(tweet)

# So... how many tweet objects have 'text' content inside?
print (len(tweets_list))


############### Section 2 ###############
# We will use "pandas" package to draw bar charts.
# We need to use a specific "Data Frame" used by pandas.
tweets = pd.DataFrame()

# It will extract "text" element in tweets_list.
# Go to JSON Viewer and locate "text" element.
tweets['text'] = list(map(lambda tweet: tweet['text'], tweets_list))

# This line extracts "lang" element in tweets data.
tweets['lang'] = list(map(lambda tweet: tweet['lang'], tweets_list))

# This line extracts "country" element in tweets data.
# "country" is a child of "place" in the JSON hierarchy.
tweets['country'] = list(map(lambda tweet: tweet['place']['country']
                        if tweet['place'] != None
                        else
                            None,
                    tweets_list))

# So... how many tweets have 'text', 'lang' and 'country'.
print ('# of tweets with text   : ', len(tweets['text']))
print ('# of tweets with lang   : ', len(tweets['lang']))
print ('# of tweets with countr : ', len(tweets['country']))

# Have a look at what lambda/map returned to us. Let’s have a look at the first 10 items.
print ( (tweets['text'])[0:10] )