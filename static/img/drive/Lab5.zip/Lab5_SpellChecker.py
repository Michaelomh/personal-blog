import enchant
from enchant.checker import SpellChecker
from nltk.metrics.distance import edit_distance

dictionary_path = r'C:\Users\kjshim\AppData\Roaming\Python\Python36\site-packages\enchant\share\enchant\myspell'
enchant.set_param("enchant.myspell.dictionary.path", dictionary_path)

class MySpellChecker():

    def __init__(self, dict_name='en_US', max_dist=2):
        self.spell_dict = enchant.Dict(dict_name)
        self.max_dist = max_dist

    def replace(self, word):
        suggestions = self.spell_dict.suggest(word)

        if suggestions:
            for suggestion in suggestions:
                print ("Suggested correct word: ", suggestion)
                print ("    Edit Distance: ", edit_distance(word, suggestion))
                if edit_distance(word, suggestion) <= self.max_dist:
                    return suggestions[0]

        return word

# Let's see if we can perform spell checking on this sentence with some spelling errors.
text = "This stdent mised class two times."

my_spell_checker = MySpellChecker(max_dist=1)

# Need to install Aspell English Dictionary at http://aspell.net/win32/
chkr = SpellChecker("en_US", text)

for err in chkr:
    print(err.word + " at position " + str(err.wordpos))
    err.replace(my_spell_checker.replace(err.word))

text_spellchecked = chkr.get_text()
print(text_spellchecked)