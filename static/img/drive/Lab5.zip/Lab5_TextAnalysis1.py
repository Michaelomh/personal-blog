'''
Lab 5 (Part 1)

This script builds on Lab 4.
It now performs spell checking before stemming.

As usual, we will clean the text by:
- Removing punctuations
- Removing stop words
- Performing spell checking (be careful when spell check - e.g. SMRT, MRT)
- Performing stemming (if necessary)

Next, we will perform sentiment scoring by:
- Perform Part-Of-Speech (POS) tagging
- Extract out Verbs, Nouns and Adjectives
- Perform dictionary-based sentiment scoring
--> If a term is identified to be positive, assign a score of +1
--> If a term is identified to be negative, assign a score of -1

'''

from nltk.tokenize import sent_tokenize, word_tokenize, RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import enchant
from enchant.checker import SpellChecker
from nltk.metrics.distance import edit_distance

# We need to tell Enchant... where the new dictionarie are located.
dictionary_path = r'C:\Users\kjshim\AppData\Roaming\Python\Python36\site-packages\enchant\share\enchant\myspell'
enchant.set_param("enchant.myspell.dictionary.path", dictionary_path)

############### Section 1 ###############

# Specify input file
news_article_path = 'StraitsTimes1.txt'

# Open the file, read in all the news content and make a single sentence.
news_article_file = open(news_article_path, 'r')
news_content = ''
# Read one line at a time
for line in news_article_file:
    if len(line.strip()) > 0:
        news_content = news_content + line + ' '

# See what it looks like.
print (news_content)

# Let's lower-case all words.
news_content = news_content.lower()

# See what it looks like.
print (news_content)


############### Section 2 ###############
# sent_tokenize() function takes a text blob and breaks it into 'sentences'.
news_sentences = sent_tokenize(news_content)
print (news_sentences)
# How many sentences are in this news article?
print (len(news_sentences))


############### Section 3 ###############
# word_tokenize() function takes a text blob and breaks it into 'words'.
tokenizer = RegexpTokenizer(r'\w+')
#news_words = word_tokenize(news_content)
news_words = tokenizer.tokenize(news_content)
print (news_words)
# How many words are in this news article?
print (len(news_words))


############### Section 4 ###############
# Let's load up English corpus from NLTK package.
stop_words = stopwords.words('english')
# See what words are inside.
print (stop_words)


############### Section 5 ###############
# Let's remove stop words from the news content.
#news_words_filtered = [w for w in news_words if not w in stop_words]

news_words_filtered = []

for w in news_words:
    if w not in stop_words:
        news_words_filtered.append(w)

# After removing stop words, how many words remain?
print (len(news_words_filtered))

# Append all words into a single string for spell checking.
news_words_filtered_string = " ".join(news_words_filtered)


############### Section 6 ###############
# Let's perform spelling correction.
# For this, we need a new package called enchant (package name: "pyenchant").
# Please go and download/install it.
# Enchant does not come with default dictionaries. You must download it.
# We already downloaded MySpell, a popular English (U.S.) dictionary used for spell checking.

# Some thinking point...
# "smrt" isn't registered in the dictionary. So, it will probably try to "correct" this.

# This is a helpder class for spell checking.
class MySpellChecker():

    def __init__(self, dict_name='en_US', max_dist=2):
        self.spell_dict = enchant.Dict(dict_name)
        self.max_dist = max_dist

    def replace(self, word):
        suggestions = self.spell_dict.suggest(word)

        if suggestions:
            for suggestion in suggestions:
                if edit_distance(word, suggestion) <= self.max_dist:
                    return suggestions[0]

        return word

#text = "This stdent mised class two times."
my_spell_checker = MySpellChecker(max_dist=1)

# Need to install Aspell English Dictionary at http://aspell.net/win32/
chkr = SpellChecker("en_US", news_words_filtered_string)

for err in chkr:
    print(err.word + " at position " + str(err.wordpos))
    err.replace(my_spell_checker.replace(err.word))

news_words_filtered_string_spellchecked = chkr.get_text()
print(news_words_filtered_string_spellchecked)

#exit(1)

# Split the spell checked single string into a list of words - for stemming.
# word_tokenize() function takes a text blob and breaks it into 'words'.
tokenizer = RegexpTokenizer(r'\w+')
news_words_filtered = tokenizer.tokenize(news_words_filtered_string_spellchecked)

print (news_words_filtered)


############### Section 7 ###############
# Let's create a Porter Stemmer object.
porter_stemmer = PorterStemmer()

# Let's test out this stemmer.
#some_words = ["ride", "rides", "riding"]
#for w in some_words:
#    print (porter_stemmer.stem(w))

# Let's stem all the words in our news article.
news_words_filtered_stemmed = []
for w in news_words_filtered:
    news_words_filtered_stemmed.append(porter_stemmer.stem(w))

print (news_words_filtered_stemmed)


############### Section 8 ###############

# Word Cloud takes a string. Convert our list of words into a string.
words_joined = " ".join([w for w in news_words_filtered_stemmed])
#words_joined = " ".join([w for w in news_words_filtered])

# Create a word cloud
my_wordcloud = WordCloud(background_color='white',
                         width=1800,
                         height=1400).generate(words_joined)

plt.imshow(my_wordcloud)
plt.axis('off')
plt.show()
plt.savefig('WordCloud.png', dpi=300)


############### Section 9 ###############
'''
# Create a word cloud
my_wordcloud = WordCloud(
    background_color='black',
    width=1800,
    height=1400,
    font_path='C:\\Windows\\Fonts\\CabinSketch-Bold.otf').generate(words_joined)

plt.imshow(my_wordcloud)
plt.axis('off')
plt.show()
plt.savefig('WordCloud2.png', dpi=300)

'''
